from .view3 import main3
from .test import test
from .register import register
from .login import login
from .logout import logout
from .updateinfo import updateinfo
# from .search import search
from .updatelocation import updatelocation
from .nearpeople import nearpeople
from .first_login import first_login
from .login_uuid import login_uuid
from .updateinfo_uuid import updateinfo_uuid